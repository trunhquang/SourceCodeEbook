//
//  AppDelegate.swift
//  State Lab
//
//  Created by Kim Topley on 10/31/15.
//  Copyright © 2015 Apress Inc. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        print(__FUNCTION__)
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        print(__FUNCTION__)
    }

    func applicationDidEnterBackground(application: UIApplication) {
        print(__FUNCTION__)
    }

    func applicationWillEnterForeground(application: UIApplication) {
        print(__FUNCTION__)
    }

    func applicationDidBecomeActive(application: UIApplication) {
        print(__FUNCTION__)
    }

    func applicationWillTerminate(application: UIApplication) {
        print(__FUNCTION__)
    }
}

